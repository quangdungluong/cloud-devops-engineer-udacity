# Running tests
```bash
pipenv install

pipenv run test
```

# Running linter
```bash
pipenv run lint
```

# Build and run
```bash
pipenv run serve
```